/*navigation du menu script*/
var linkRules = null;/*Déclaration de la variable pour le lien "les règles du forum"*/
var linkCharte = null;/*Déclaration de la variable pour le lien "La charte du forum"*/
var linkAccueil = null;/*Déclaration de la variable pour le lien "retour à l'accueil"*/

/*Objet pour l'iframe du contenu*/
var iframeContent = null;
/*Déclaration de la variable pour l'élément iframe où le contenu de la page sera chargé dinamiquement*/

/*Les constantes pour les  chemins des pages à charger dans l'iframe*/
const Page_Accueil="pages_html/accueil.html";
/*Constantes pour charger la page dans l'iframe,permettant une gestion centralisés des URLs 
et facilitant les modifications futures si nécessaires*/ 
const Page_Regles= "pages_html/regles.html";
/*Constantes pour charger la page dans l'iframe,permettant une gestion centralisés des URLs 
et facilitant les modifications futures si nécessaires*/ 
const Page_Charte= "pages_html/charte.html";
/*Constantes pour charger la page dans l'iframe,permettant une gestion centralisés des URLs 
et facilitant les modifications futures si nécessaires*/ 



/*Définir les éléments du menu */
function init(){
    linkRules = document.getElementById("link-rules");
    /*c'est l'objet qui correspond "regles du forum" au lien regles de navigation*/
    linkCharte = document.getElementById("link-charte");
    /*c'est l'objet qui correspond  "charte du forum" au lien charte*/
    linkAccueil = document.getElementById("link-accueil");
    /*c'est l'objet qui correspond "retour à l'accueil" au lien de l'accueil*/
    iframeContent = document.getElementById("iframe-content");
    /*c'est l'élément iframe au lien du contenu de l'iframe*/
    console.log(linkRules)
    console.log(linkCharte)
    console.log(linkAccueil)
    
    loadPage(Page_Accueil);
    // bug  cause :
    // file:///C:/Users/Util/Desktop/pages_html/accueil.html
    // correctif
    //file:///C:/Users/Util/Desktop/forumPqdi/pages_html/accueil.html

    eventListeners()/*Appelle de la fonction pour ajouter les écouteurs d'évènement au liens du menu*/
}

function loadPage(pageUrl){
    iframeContent.src = pageUrl;/*Met à jour la source de l'iframe pour charger la spécifiée*/

}

function eventListeners(){

    
        linkRules.addEventListener('click',(e) =>{
            loadPage(Page_Regles);
        });

    
        linkCharte.addEventListener('click',(e) =>{
            loadPage(Page_Charte);
        });

        linkAccueil.addEventListener('click',(e) =>{
                loadPage(Page_Accueil);
        });
}







